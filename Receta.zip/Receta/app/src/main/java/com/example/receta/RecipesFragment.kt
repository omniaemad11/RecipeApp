package com.example.receta

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch

class RecipesFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_recipes, container, false)
        val recycler = view.findViewById<RecyclerView>(R.id.recycler)
        lifecycleScope.launch {
            val  recipesList = ApiService.recipesService.getRecipes()
            val adapter = RecipesAdapter(recipesList, ::navigateToRecipeDetails)
            recycler.adapter = adapter
        }

        return (view)
    }

    private fun navigateToRecipeDetails(id: Int): Unit {
        findNavController().navigate(
            RecipesFragmentDirections.actionRecipesFragmentToRecipeDetailsFragment()


        )

    }


}

